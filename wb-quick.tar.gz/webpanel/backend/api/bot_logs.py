"""
봇 로그 API 핸들러

Docker 컨테이너 로그를 실시간 SSE 스트리밍 또는 일괄 조회
"""
import subprocess
import json
import time
from flask import jsonify, request, Response, stream_with_context

BOT_CONTAINER_NAME = 'debi-marlene'
DASHBOARD_CONTAINER_NAME = 'debi-marlene-dashboard'


def get_bot_logs():
    """API: 봇 컨테이너 로그 최근 N줄 조회"""
    tail = request.args.get('tail', 200, type=int)
    filter_text = request.args.get('filter', '').strip()
    container = request.args.get('container', BOT_CONTAINER_NAME)

    # 허용된 컨테이너만
    allowed = [BOT_CONTAINER_NAME, DASHBOARD_CONTAINER_NAME, 'webpanel-backend']
    if container not in allowed:
        return jsonify({'success': False, 'error': 'Invalid container'}), 400

    try:
        result = subprocess.run(
            ['docker', 'logs', '--tail', str(tail), '--timestamps', container],
            capture_output=True, text=True, timeout=10
        )
        # docker logs는 stdout + stderr 모두 사용
        lines = (result.stdout + result.stderr).strip().split('\n')

        if filter_text:
            lines = [l for l in lines if filter_text.lower() in l.lower()]

        return jsonify({
            'success': True,
            'logs': lines,
            'container': container,
            'total': len(lines)
        })
    except subprocess.TimeoutExpired:
        return jsonify({'success': False, 'error': 'Timeout'}), 504
    except FileNotFoundError:
        return jsonify({
            'success': False,
            'error': 'Docker not available (local dev?)',
            'logs': ['[INFO] Docker is not available in this environment.']
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


def stream_bot_logs():
    """API: SSE를 통한 봇 컨테이너 로그 실시간 스트리밍"""
    tail = request.args.get('tail', 100, type=int)
    container = request.args.get('container', BOT_CONTAINER_NAME)

    allowed = [BOT_CONTAINER_NAME, DASHBOARD_CONTAINER_NAME, 'webpanel-backend']
    if container not in allowed:
        return Response('Invalid container', status=400)

    def generate():
        process = None
        try:
            process = subprocess.Popen(
                ['docker', 'logs', '--follow', '--tail', str(tail), '--timestamps', container],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )

            # 연결 확인 이벤트
            yield f"data: {json.dumps({'type': 'connected', 'container': container})}\n\n"

            for line in iter(process.stdout.readline, ''):
                line = line.rstrip('\n')
                if line:
                    yield f"data: {json.dumps({'type': 'log', 'line': line})}\n\n"

        except FileNotFoundError:
            yield f"data: {json.dumps({'type': 'error', 'message': 'Docker not available'})}\n\n"
        except GeneratorExit:
            pass
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"
        finally:
            if process:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()

    return Response(
        stream_with_context(generate()),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'X-Accel-Buffering': 'no',
            'Connection': 'keep-alive'
        }
    )


def get_container_status():
    """API: 컨테이너 상태 조회"""
    containers = [BOT_CONTAINER_NAME, DASHBOARD_CONTAINER_NAME, 'webpanel-backend']
    statuses = {}

    for name in containers:
        try:
            result = subprocess.run(
                ['docker', 'inspect', '--format',
                 '{{.State.Status}}|{{.State.StartedAt}}|{{.RestartCount}}',
                 name],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                parts = result.stdout.strip().split('|')
                statuses[name] = {
                    'status': parts[0] if len(parts) > 0 else 'unknown',
                    'started_at': parts[1] if len(parts) > 1 else '',
                    'restart_count': int(parts[2]) if len(parts) > 2 else 0,
                }
            else:
                statuses[name] = {'status': 'not_found'}
        except Exception:
            statuses[name] = {'status': 'error'}

    return jsonify({
        'success': True,
        'containers': statuses
    })
