"""
헬퍼 함수들
"""


def get_discord_avatar_url(user_id, avatar_hash):
    """Discord 사용자 아바타 URL 생성 (애니메이션 GIF 지원)"""
    if avatar_hash:
        # a_로 시작하면 애니메이션 GIF, 아니면 PNG
        ext = 'gif' if avatar_hash.startswith('a_') else 'png'
        return f"https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.{ext}?size=128"
    else:
        # 기본 Discord 아바타
        return f"https://cdn.discordapp.com/embed/avatars/{int(user_id) % 5}.png"
