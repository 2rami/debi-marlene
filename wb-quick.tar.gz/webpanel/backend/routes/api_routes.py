"""
API 라우트 등록
"""
from flask import Blueprint, redirect
from backend.utils.decorators import login_required
from backend.api import auth, servers, settings, channels, members, messages, users, announcement, notifications, quiz, bot_logs, dashboard_logs

api_bp = Blueprint('api', __name__, url_prefix='/api')


# 인증 API
@api_bp.route('/check-auth')
def check_auth():
    """로그인 상태 확인 API"""
    return auth.check_auth()


@api_bp.route('/logout', methods=['POST'])
def logout_api():
    """로그아웃 API"""
    return auth.logout()


@api_bp.route('/auth/discord')
def discord_auth():
    """Discord OAuth 인증 시작"""
    return redirect('/auth/discord')


# 서버 API
@api_bp.route('/discord/servers')
@api_bp.route('/servers')
def get_servers():
    """서버 목록 조회"""
    return servers.get_servers()


@api_bp.route('/bot-info', methods=['GET'])
def bot_info():
    """봇 정보 가져오기"""
    return servers.get_bot_info()


# 설정 API
@api_bp.route('/raw-settings')
@login_required
def raw_settings():
    """원본 설정 파일 조회"""
    return settings.get_raw_settings()


@api_bp.route('/load-settings', methods=['GET'])
def load_settings_api():
    """GCS에서 설정 파일 로드"""
    return settings.load_settings()


@api_bp.route('/save-settings', methods=['POST'])
@login_required
def save_settings():
    """설정 파일 저장"""
    return settings.save_settings()


# 채널 API
@api_bp.route('/discord/guilds/<guild_id>/channels')
@api_bp.route('/discord/channels/<guild_id>')
@api_bp.route('/channels/<guild_id>')
def get_channels(guild_id):
    """Discord 서버 채널 목록 조회"""
    return channels.get_channels(guild_id)


@api_bp.route('/discord/voice-channels/<channel_id>/members')
def get_voice_channel_members(channel_id):
    """음성 채널에 접속한 멤버 목록 조회"""
    return channels.get_voice_channel_members(channel_id)


@api_bp.route('/discord/channels/<channel_id>/threads')
@api_bp.route('/discord/guilds/<guild_id>/channels/<channel_id>/threads')
def get_forum_threads(channel_id, guild_id=None):
    """포럼 채널의 스레드 목록 조회"""
    return channels.get_forum_threads(channel_id, guild_id)


# 멤버 API
@api_bp.route('/discord/guilds/<guild_id>/members')
def get_members(guild_id):
    """Discord 서버 멤버 목록 조회"""
    return members.get_members(guild_id)


@api_bp.route('/discord/guilds/<guild_id>/roles')
def get_roles(guild_id):
    """Discord 서버 역할 목록 조회"""
    return members.get_roles(guild_id)


# 메시지 API
@api_bp.route('/discord/channels/<channel_id>/messages', methods=['GET'])
def get_messages(channel_id):
    """Discord 채널 메시지 조회"""
    return messages.get_messages(channel_id)


@api_bp.route('/discord/channels/<channel_id>/messages', methods=['POST'])
def send_message(channel_id):
    """Discord 채널에 메시지 전송"""
    return messages.send_message(channel_id)


@api_bp.route('/discord/messages/stream', methods=['GET'])
def stream_messages():
    """실시간 메시지 스트리밍 (SSE)"""
    return messages.stream_messages()


# 사용자 API
@api_bp.route('/discord/users/@me')
@login_required
def get_bot_user():
    """Discord 봇 사용자 정보 조회"""
    return users.get_bot_user()


@api_bp.route('/discord/users/<user_id>')
def get_user_info(user_id):
    """Discord 사용자 기본 정보 조회"""
    return users.get_user_info(user_id)


@api_bp.route('/discord/users/<user_id>/profile')
def get_user_profile(user_id):
    """Discord 사용자 프로필 상세 조회 (배너, 소개, 서버 목록 포함)"""
    return users.get_user_profile(user_id)


@api_bp.route('/discord/users/@me/channels')
def get_dm_channels():
    """Discord DM 채널 목록 조회"""
    return users.get_dm_channels()


@api_bp.route('/discord/users/@me/channels', methods=['POST'])
def create_dm_channel():
    """Discord DM 채널 생성"""
    return users.create_dm_channel()


# 공지 API
@api_bp.route('/announcement/servers', methods=['GET'])
def get_announcement_servers():
    """공지 채널이 설정된 서버 목록 조회"""
    return announcement.get_announcement_servers()


@api_bp.route('/announcement/subscribers', methods=['GET'])
def get_youtube_subscribers():
    """유튜브 알림 구독자 목록 조회"""
    return announcement.get_youtube_subscribers()


@api_bp.route('/announcement/send', methods=['POST'])
def send_announcement():
    """공지 메시지 전송"""
    return announcement.send_announcement()


# 알림 API
@api_bp.route('/notifications', methods=['GET'])
def get_command_logs():
    """명령어 사용 로그 조회"""
    return notifications.get_command_logs()


# 퀴즈 곡 관리 API
@api_bp.route('/quiz/songs', methods=['GET'])
@login_required
def get_quiz_songs():
    """글로벌 퀴즈 곡 목록 조회"""
    return quiz.get_songs()


@api_bp.route('/quiz/songs', methods=['POST'])
@login_required
def add_quiz_song():
    """글로벌 퀴즈 곡 추가"""
    return quiz.add_song()


@api_bp.route('/quiz/songs/<int:index>', methods=['PUT'])
@login_required
def update_quiz_song(index):
    """글로벌 퀴즈 곡 수정"""
    return quiz.update_song(index)


@api_bp.route('/quiz/songs/<int:index>', methods=['DELETE'])
@login_required
def delete_quiz_song(index):
    """글로벌 퀴즈 곡 삭제"""
    return quiz.delete_song(index)


# 봇 로그 API
@api_bp.route('/bot-logs', methods=['GET'])
def get_bot_logs():
    """봇 컨테이너 로그 조회"""
    return bot_logs.get_bot_logs()


@api_bp.route('/bot-logs/stream', methods=['GET'])
def stream_bot_logs():
    """봇 컨테이너 로그 실시간 스트리밍 (SSE)"""
    return bot_logs.stream_bot_logs()


@api_bp.route('/container-status', methods=['GET'])
def container_status():
    """컨테이너 상태 조회"""
    return bot_logs.get_container_status()


# 대시보드 사용 로그 API
@api_bp.route('/dashboard-logs', methods=['GET'])
def get_dashboard_logs():
    """대시보드 사용 로그 조회"""
    return dashboard_logs.get_dashboard_logs()


@api_bp.route('/dashboard-logs', methods=['POST'])
def log_dashboard_action():
    """대시보드 액션 기록"""
    return dashboard_logs.log_dashboard_action_api()


# 음성 활동 API
@api_bp.route('/voice-activity', methods=['GET'])
def get_voice_activity():
    """음성 채널에 멤버가 있는 서버 목록"""
    from flask import jsonify
    from backend.gateway import get_gateway_service

    gateway = get_gateway_service()
    if gateway and gateway.is_ready():
        return jsonify({
            'success': True,
            'voice_activity': gateway.get_guilds_with_voice_activity()
        })

    return jsonify({
        'success': False,
        'voice_activity': {}
    })
