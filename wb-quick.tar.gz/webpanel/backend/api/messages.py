"""
메시지 API 핸들러
"""
import asyncio
import aiohttp
import json
import time
from flask import jsonify, request, Response, stream_with_context
import requests as req
from backend.services.discord_api import send_discord_message
from backend.config import DISCORD_HEADERS
from backend.utils.helpers import get_discord_avatar_url
from backend.gateway import get_gateway_service


def get_messages(channel_id):
    """API: Discord 채널 메시지 조회 (REST API 전용)"""
    try:
        limit = request.args.get('limit', 100, type=int)
        limit = min(limit, 100)  # 최대 100개로 제한
        before = request.args.get('before')  # 이 메시지 이전의 메시지 로드

        # 임시 DM 채널 ID 감지 (temp_{user_id})
        if channel_id.startswith('temp_'):
            user_id = channel_id.replace('temp_', '')
            print(f"🔄 임시 채널 ID 감지 - DM 채널 자동 생성 시도: {user_id}")

            # Discord API로 DM 채널 생성
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)

                async def create_dm():
                    async with aiohttp.ClientSession() as session:
                        async with session.post(
                            'https://discord.com/api/v10/users/@me/channels',
                            headers=DISCORD_HEADERS,
                            json={'recipient_id': user_id}
                        ) as response:
                            if response.status == 200:
                                return await response.json()
                            else:
                                print(f"❌ DM 채널 생성 실패: {response.status}")
                                return None

                dm_channel = loop.run_until_complete(create_dm())
                loop.close()

                if dm_channel and dm_channel.get('id'):
                    channel_id = dm_channel['id']
                    print(f"✅ DM 채널 생성 성공: {channel_id}")

                    # GCS에 저장
                    from run.core import config
                    settings = config.load_settings()
                    if user_id in settings.get('users', {}):
                        settings['users'][user_id]['dm_channel_id'] = channel_id
                        config.save_settings(settings, silent=True)
                        print(f"✅ DM 채널 ID GCS에 저장 완료")
                else:
                    print(f"❌ DM 채널 생성 실패 - 빈 메시지 반환")
                    return jsonify({
                        'success': False,
                        'messages': [],
                        'count': 0,
                        'data_source': 'DM 채널 생성 실패',
                        'error': 'DM 채널을 생성할 수 없습니다.'
                    })
            except Exception as e:
                print(f"❌ DM 채널 생성 오류: {e}")
                return jsonify({
                    'success': False,
                    'messages': [],
                    'count': 0,
                    'data_source': 'Error',
                    'error': str(e)
                })

        # Discord REST API로 메시지 조회
        params = {'limit': limit}
        if before:
            params['before'] = before
            print(f"Discord REST API로 메시지 로드: {channel_id} (before: {before})")
        else:
            print(f"Discord REST API로 메시지 로드: {channel_id}")

        try:
            response = req.get(
                f'https://discord.com/api/v10/channels/{channel_id}/messages',
                headers=DISCORD_HEADERS,
                params=params
            )
            if response.status_code == 200:
                messages_data = response.json()
                # Discord API 응답 형식 변환
                messages = []
                for msg in messages_data:
                    author = msg['author']
                    member = msg.get('member')  # 서버 멤버 정보
                    msg_type = msg.get('type', 0)

                    # 서버별 닉네임 우선 사용
                    display_name = author.get('username', 'Unknown')
                    if member and member.get('nick'):
                        display_name = member['nick']
                    elif author.get('global_name'):
                        display_name = author['global_name']

                    # 서버별 아바타 우선 사용
                    avatar_hash = author.get('avatar')
                    if member and member.get('avatar'):
                        avatar_hash = member['avatar']

                    # 아바타 URL 생성
                    avatar_url = get_discord_avatar_url(author['id'], avatar_hash)

                                        # 답장 정보 처리
                    referenced_message = None
                    if msg.get('referenced_message'):
                        ref_msg = msg['referenced_message']
                        ref_author = ref_msg.get('author', {})
                        referenced_message = {
                            'id': ref_msg.get('id'),
                            'content': ref_msg.get('content', ''),
                            'author': {
                                'id': ref_author.get('id'),
                                'username': ref_author.get('username', 'Unknown'),
                                'display_name': ref_author.get('global_name') or ref_author.get('username', 'Unknown')
                            }
                        }

                    # interaction 정보 처리 (슬래시 명령어 등)
                    # Discord API v10: interaction 또는 interaction_metadata 둘 다 체크
                    interaction = None
                    inter_data = msg.get('interaction') or msg.get('interaction_metadata')
                    if inter_data:
                        inter_user = inter_data.get('user', {})
                        # name이 없을 수 있음 (interaction_metadata에서는 name 필드가 없음)
                        inter_name = inter_data.get('name')
                        if not inter_name:
                            # type이 2면 슬래시 명령어
                            inter_name = '명령어'
                        interaction = {
                            'id': inter_data.get('id'),
                            'type': inter_data.get('type'),
                            'name': inter_name,
                            'user': {
                                'id': inter_user.get('id'),
                                'username': inter_user.get('username', 'Unknown'),
                                'display_name': inter_user.get('global_name') or inter_user.get('username', 'Unknown')
                            }
                        }

                    messages.append({
                        'id': msg['id'],
                        'content': msg['content'],
                        'type': msg_type,  # 메시지 타입 (0: 일반, 7: 환영, 8: 부스트 등)
                        'flags': msg.get('flags', 0),  # 메시지 플래그 (32768 = IS_COMPONENTS_V2)
                        'author': {
                            'id': author['id'],
                            'username': author['username'],
                            'display_name': display_name,
                            'discriminator': author.get('discriminator', '0'),
                            'avatar': avatar_hash,
                            'avatar_url': avatar_url,
                            'bot': author.get('bot', False)
                        },
                        'member': {
                            'nick': member.get('nick') if member else None,
                            'roles': member.get('roles', []) if member else []
                        } if member else None,
                        'timestamp': msg['timestamp'],
                        'edited_timestamp': msg.get('edited_timestamp'),
                        'attachments': msg.get('attachments', []),
                        'embeds': msg.get('embeds', []),
                        'components': msg.get('components', []),  # Components V2 데이터
                        'referenced_message': referenced_message,
                        'interaction': interaction,
                        'message_reference': msg.get('message_reference')
                    })
                data_source = "Discord REST API"
            elif response.status_code == 403:
                print(f"Discord API 권한 오류: {channel_id}")
                return jsonify({
                    'success': False,
                    'error': 'permission_denied',
                    'error_message': '이 채널에 접근 권한이 없습니다.',
                    'messages': [],
                    'count': 0
                })
            elif response.status_code == 404:
                print(f"Discord API 채널 없음: {channel_id}")
                return jsonify({
                    'success': False,
                    'error': 'not_found',
                    'error_message': '채널을 찾을 수 없습니다.',
                    'messages': [],
                    'count': 0
                })
            else:
                print(f"Discord API 오류: {response.status_code}")
                return jsonify({
                    'success': False,
                    'error': 'api_error',
                    'error_message': f'Discord API 오류 ({response.status_code})',
                    'messages': [],
                    'count': 0
                })
        except Exception as e:
            print(f"Discord API 요청 실패: {e}")
            return jsonify({
                'success': False,
                'error': 'request_failed',
                'error_message': '메시지를 불러오는데 실패했습니다.',
                'messages': [],
                'count': 0
            })

        return jsonify({
            'success': True,
            'messages': messages,
            'data_source': data_source,
            'count': len(messages)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'messages': []
        })


def send_message(channel_id):
    """API: Discord 채널에 메시지 전송 (REST API 전용, 임베드 지원)"""
    try:
        data = request.get_json()
        content = data.get('content', '').strip() if data.get('content') else None
        embed = data.get('embed')

        # content나 embed 중 하나는 있어야 함
        if not content and not embed:
            return jsonify({
                'success': False,
                'error': '메시지 내용이 비어있습니다.'
            })

        # Discord REST API로 메시지 전송
        print(f"REST API로 메시지 전송: {channel_id}, embed: {bool(embed)}")
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(send_discord_message(channel_id, content, DISCORD_HEADERS, embed=embed))
        loop.close()
        data_source = "Discord REST API"

        if result:
            return jsonify({
                'success': True,
                'message': result,
                'data_source': data_source
            })
        else:
            return jsonify({
                'success': False,
                'error': '메시지 전송에 실패했습니다.',
                'data_source': data_source
            })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })


def stream_messages():
    """API: SSE를 통한 실시간 메시지 스트리밍 (Gateway 이벤트)"""
    def generate():
        """SSE 이벤트 생성기"""
        gateway = get_gateway_service()

        if not gateway:
            print("Gateway 서비스가 초기화되지 않음")
            yield f"data: {json.dumps({'error': 'Gateway 서비스가 준비되지 않았습니다.'})}\n\n"
            return

        if not gateway.is_ready():
            print("Gateway 서비스가 준비되지 않음")
            yield f"data: {json.dumps({'error': 'Gateway 연결 대기 중...'})}\n\n"
            return

        # 연결 성공 메시지
        yield f"data: {json.dumps({'type': 'CONNECTED', 'message': '실시간 메시지 스트림 연결됨'})}\n\n"

        last_message_id = 0

        try:
            while True:
                # 새 메시지 이벤트 확인 (last_message_id 이후 것만)
                events = gateway.get_recent_message_events(since_id=last_message_id)

                for event in events:
                    # 마지막 메시지 ID 업데이트
                    msg_id = int(event['message']['id'])
                    if msg_id > last_message_id:
                        last_message_id = msg_id

                    # SSE 형식으로 전송
                    yield f"data: {json.dumps(event)}\n\n"

                # 1초마다 확인 (너무 자주 확인하면 부하가 걸릴 수 있음)
                time.sleep(1)

        except GeneratorExit:
            print("클라이언트 연결 종료")
        except Exception as e:
            print(f"SSE 스트림 오류: {e}")
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'X-Accel-Buffering': 'no',  # nginx 버퍼링 비활성화
            'Connection': 'keep-alive'
        }
    )
