"""
대시보드 사용 로그 API 핸들러

대시보드에서 수행된 액션(설정 변경 등)을 GCS에서 조회
"""
import json
from datetime import datetime, timezone, timedelta
from flask import jsonify, request

KST = timezone(timedelta(hours=9))
GCS_DASHBOARD_LOGS_KEY = 'dashboard_logs.json'


def _load_dashboard_logs_from_gcs():
    """GCS에서 대시보드 로그 로드"""
    try:
        from google.cloud import storage
        client = storage.Client()
        bucket = client.bucket('debi-marlene-settings')
        blob = bucket.blob(GCS_DASHBOARD_LOGS_KEY)

        if blob.exists():
            content = blob.download_as_text()
            return json.loads(content)
    except Exception as e:
        print(f"[대시보드 로그] GCS 로드 실패: {e}", flush=True)

    return []


def _save_dashboard_logs_to_gcs(logs):
    """GCS에 대시보드 로그 저장"""
    try:
        from google.cloud import storage
        client = storage.Client()
        bucket = client.bucket('debi-marlene-settings')
        blob = bucket.blob(GCS_DASHBOARD_LOGS_KEY)
        blob.upload_from_string(
            json.dumps(logs, ensure_ascii=False, indent=2),
            content_type='application/json'
        )
        return True
    except Exception as e:
        print(f"[대시보드 로그] GCS 저장 실패: {e}", flush=True)
        return False


def save_dashboard_action(action_type, user_info, guild_id=None, guild_name=None, details=None):
    """대시보드 액션을 GCS에 기록 (다른 모듈에서 호출)"""
    log_entry = {
        'action': action_type,
        'user_id': user_info.get('id', 'unknown'),
        'user_name': user_info.get('username', 'unknown'),
        'guild_id': guild_id,
        'guild_name': guild_name,
        'details': details or {},
        'timestamp': datetime.now(KST).isoformat(),
    }

    logs = _load_dashboard_logs_from_gcs()
    logs.insert(0, log_entry)

    # 최대 500개 유지 (약 30일치)
    logs = logs[:500]
    _save_dashboard_logs_to_gcs(logs)
    return log_entry


def get_dashboard_logs():
    """API: 대시보드 사용 로그 조회"""
    try:
        logs = _load_dashboard_logs_from_gcs()

        # 필터
        action_filter = request.args.get('action', '').strip()
        user_filter = request.args.get('user_id', '').strip()
        guild_filter = request.args.get('guild_id', '').strip()
        limit = request.args.get('limit', 100, type=int)

        if action_filter:
            logs = [l for l in logs if l.get('action') == action_filter]
        if user_filter:
            logs = [l for l in logs if l.get('user_id') == user_filter]
        if guild_filter:
            logs = [l for l in logs if l.get('guild_id') == guild_filter]

        logs = logs[:limit]

        # 액션별 통계
        action_stats = {}
        for log in logs:
            action = log.get('action', 'unknown')
            action_stats[action] = action_stats.get(action, 0) + 1

        return jsonify({
            'success': True,
            'logs': logs,
            'total': len(logs),
            'action_stats': action_stats
        })

    except Exception as e:
        print(f"[대시보드 로그] 조회 실패: {e}", flush=True)
        return jsonify({
            'success': False,
            'error': str(e),
            'logs': []
        }), 500


def log_dashboard_action_api():
    """API: 대시보드 액션 기록 (대시보드 백엔드에서 호출)"""
    try:
        data = request.json
        if not data or not data.get('action'):
            return jsonify({'success': False, 'error': 'action required'}), 400

        entry = save_dashboard_action(
            action_type=data['action'],
            user_info=data.get('user', {}),
            guild_id=data.get('guild_id'),
            guild_name=data.get('guild_name'),
            details=data.get('details')
        )

        return jsonify({'success': True, 'entry': entry})

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
