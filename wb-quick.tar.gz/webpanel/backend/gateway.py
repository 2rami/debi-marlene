#!/usr/bin/env python3
"""
웹패널용 Discord Gateway 서비스
- 실시간 멤버 리스트
- 온라인/오프라인 상태 표시
- 역할 색상 표시
"""

import discord
import asyncio
import threading
import time
import logging
from typing import Dict, List, Optional

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class WebPanelGatewayService:
    """웹패널 전용 Discord Gateway 서비스 - 멤버 리스트 및 온라인 상태"""

    def __init__(self, token: str):
        # 멤버 정보와 온라인 상태를 위한 Intents 설정
        intents = discord.Intents.default()
        intents.members = True  # 멤버 정보
        intents.presences = False  # Discord 미승인 (100+ 서버)
        intents.guilds = True  # 서버 정보
        intents.voice_states = True  # 음성 상태
        intents.message_content = True  # 메시지 내용
        intents.messages = True  # 메시지 이벤트

        self.client = discord.Client(intents=intents)
        self.token = token
        self.ready = False

        # 실시간 메시지 이벤트를 저장할 큐 (최근 100개만 유지)
        self.message_events = []
        self.max_events = 100

        # 이벤트 핸들러 등록
        self.setup_event_handlers()

    def setup_event_handlers(self):
        """Discord 이벤트 핸들러 설정"""

        @self.client.event
        async def on_ready():
            logger.info(f'웹패널 Gateway 연결 완료: {self.client.user}')
            logger.info(f'연결된 서버 수: {len(self.client.guilds)}')
            self.ready = True
            logger.info(f'웹패널 Gateway 준비 완료 (멤버 리스트 & 온라인 상태 & 실시간 메시지)')

        @self.client.event
        async def on_member_join(member):
            logger.info(f'멤버 참가: {member} -> {member.guild.name}')

        @self.client.event
        async def on_member_remove(member):
            logger.info(f'멤버 탈퇴: {member} -> {member.guild.name}')

        @self.client.event
        async def on_presence_update(before, after):
            # 온라인 상태 변화 감지 (로깅은 생략, 너무 많음)
            pass

        @self.client.event
        async def on_message(message):
            """새 메시지 이벤트 처리 - 실시간 업데이트를 위해 큐에 저장"""
            # 봇 자신의 메시지는 무시
            if message.author == self.client.user:
                return

            # 메시지 데이터 구성
            message_data = {
                'type': 'MESSAGE_CREATE',
                'channel_id': str(message.channel.id),
                'guild_id': str(message.guild.id) if message.guild else None,  # 서버 ID 추가 (DM은 None)
                'message': {
                    'id': str(message.id),
                    'content': message.content,
                    'type': message.type.value if hasattr(message.type, 'value') else 0,  # 메시지 타입
                    'timestamp': message.created_at.isoformat(),
                    'author': {
                        'id': str(message.author.id),
                        'username': message.author.name,
                        'display_name': message.author.display_name if hasattr(message.author, 'display_name') else message.author.name,
                        'discriminator': message.author.discriminator,
                        'avatar': message.author.display_avatar.url,
                        'bot': message.author.bot
                    },
                    'attachments': [
                        {
                            'id': str(att.id),
                            'filename': att.filename,
                            'url': att.url,
                            'size': att.size,
                            'content_type': att.content_type
                        }
                        for att in message.attachments
                    ] if message.attachments else [],
                    'embeds': len(message.embeds) if message.embeds else 0,
                }
            }

            # 이벤트 큐에 추가 (최대 100개만 유지)
            self.message_events.append(message_data)
            if len(self.message_events) > self.max_events:
                self.message_events.pop(0)  # 가장 오래된 이벤트 제거

            logger.info(f'새 메시지 수신: {message.author.name} in #{message.channel.name}: {message.content[:50]}...')

    def get_guild_members_sync(self, guild_id: str, channel_id: str = None) -> List[Dict]:
        """서버 멤버 목록 가져오기 (동기 버전)

        Args:
            guild_id: 서버 ID
            channel_id: 채널 ID (선택사항, 지정하면 해당 채널 접근 가능한 멤버만 반환)

        Returns:
            멤버 정보 리스트 (실시간 온라인 상태 포함)
        """
        try:
            guild = self.client.get_guild(int(guild_id))
            if not guild:
                logger.warning(f'서버 {guild_id}를 찾을 수 없음')
                return []

            # 채널 지정 시 해당 채널 가져오기
            channel = None
            if channel_id:
                channel = guild.get_channel(int(channel_id))
                if not channel:
                    logger.warning(f'채널 {channel_id}를 찾을 수 없음')

            members = []
            status_count = {'online': 0, 'offline': 0, 'idle': 0, 'dnd': 0}

            for member in guild.members:
                # 채널이 지정된 경우 권한 확인
                if channel:
                    perms = channel.permissions_for(member)
                    if not perms.view_channel:
                        continue  # 채널을 볼 수 없는 멤버는 제외

                # 온라인 상태 매핑
                status = 'online'
                if member.status == discord.Status.offline:
                    status = 'offline'
                elif member.status == discord.Status.idle:
                    status = 'idle'
                elif member.status == discord.Status.dnd:
                    status = 'dnd'

                status_count[status] += 1

                # 멤버의 최상위 역할 색상 찾기
                role_color = None
                for role in reversed(member.roles):  # 역순으로 순회 (최상위 역할부터)
                    if role.color.value != 0:  # 색상이 설정된 역할 찾기
                        role_color = f'#{role.color.value:06x}'
                        break

                members.append({
                    'id': str(member.id),
                    'username': member.name,
                    'display_name': member.display_name,
                    'discriminator': member.discriminator,
                    'avatar': member.display_avatar.url,
                    'status': status,  # 실시간 온라인 상태!
                    'bot': member.bot,
                    'roles': [str(role.id) for role in member.roles],
                    'role_color': role_color,
                    'top_role': str(member.top_role.id) if member.top_role else None,
                    'joined_at': member.joined_at.isoformat() if member.joined_at else None
                })

            logger.info(f'✅ Gateway에서 {len(members)}명의 멤버 가져옴')
            logger.info(f'📊 상태 분포: 온라인={status_count["online"]}, 오프라인={status_count["offline"]}, 자리비움={status_count["idle"]}, 다른용무중={status_count["dnd"]}')

            # 모든 멤버가 오프라인인 경우 경고
            if len(members) > 0 and status_count['offline'] == len(members):
                logger.warning('⚠️ 모든 멤버가 오프라인으로 표시됩니다!')
                logger.warning('⚠️ Discord Developer Portal에서 다음 Intent를 활성화했는지 확인하세요:')
                logger.warning('   1. SERVER MEMBERS INTENT')
                logger.warning('   2. PRESENCE INTENT')
                logger.warning('   Bot Settings > Privileged Gateway Intents 메뉴에서 활성화')

            return members

        except Exception as e:
            logger.error(f'❌ 멤버 목록 로드 실패 {guild_id}: {e}')
            return []

    def get_guild_roles_sync(self, guild_id: str) -> List[Dict]:
        """서버 역할 목록 가져오기 (동기 버전)"""
        try:
            guild = self.client.get_guild(int(guild_id))
            if not guild:
                logger.warning(f'서버 {guild_id}를 찾을 수 없음')
                return []

            roles = []
            for role in guild.roles:
                roles.append({
                    'id': str(role.id),
                    'name': role.name,
                    'color': f'#{role.color.value:06x}' if role.color.value != 0 else None,
                    'position': role.position,
                    'permissions': role.permissions.value,
                    'hoist': role.hoist,  # 역할을 멤버 목록에서 따로 표시할지
                    'mentionable': role.mentionable,
                    'member_count': len(role.members)
                })

            return sorted(roles, key=lambda x: x['position'], reverse=True)

        except Exception as e:
            logger.error(f'❌ 역할 목록 로드 실패 {guild_id}: {e}')
            return []

    def get_voice_channel_members_sync(self, channel_id: str) -> List[Dict]:
        """음성 채널에 접속한 멤버 목록 가져오기 (동기 버전)"""
        try:
            # 모든 서버를 순회하면서 채널 찾기
            for guild in self.client.guilds:
                channel = guild.get_channel(int(channel_id))
                if channel and isinstance(channel, discord.VoiceChannel):
                    members = []
                    for member in channel.members:
                        # 온라인 상태 매핑
                        status = 'online'
                        if member.status == discord.Status.offline:
                            status = 'offline'
                        elif member.status == discord.Status.idle:
                            status = 'idle'
                        elif member.status == discord.Status.dnd:
                            status = 'dnd'

                        # 멤버의 최상위 역할 색상 찾기
                        role_color = None
                        for role in reversed(member.roles):
                            if role.color.value != 0:
                                role_color = f'#{role.color.value:06x}'
                                break

                        # 음성 상태 정보
                        voice_state = member.voice
                        is_muted = voice_state.mute or voice_state.self_mute if voice_state else False
                        is_deafened = voice_state.deaf or voice_state.self_deaf if voice_state else False

                        members.append({
                            'id': str(member.id),
                            'username': member.name,
                            'display_name': member.display_name,
                            'discriminator': member.discriminator,
                            'avatar': member.display_avatar.url,
                            'status': status,
                            'bot': member.bot,
                            'role_color': role_color,
                            'voice_state': {
                                'muted': is_muted,
                                'deafened': is_deafened,
                                'streaming': voice_state.self_stream if voice_state else False,
                                'video': voice_state.self_video if voice_state else False
                            }
                        })

                    # 0명일 때는 로그 안 찍음 (너무 많음)
                    if len(members) > 0:
                        logger.info(f'✅ 음성 채널 {channel.name}에 {len(members)}명 접속 중')
                    return members

            logger.warning(f'음성 채널 {channel_id}를 찾을 수 없음')
            return []

        except Exception as e:
            logger.error(f'❌ 음성 채널 멤버 목록 로드 실패 {channel_id}: {e}')
            return []

    def get_guilds_with_voice_activity(self) -> Dict[str, dict]:
        """음성 채널에 멤버가 있는 서버 목록 반환 (봇 접속 여부 포함)"""
        try:
            bot_id = str(self.client.user.id) if self.client.user else None
            result = {}
            for guild in self.client.guilds:
                bot_connected = False
                bot_channel_name = None
                for channel in guild.voice_channels:
                    # 봇이 이 채널에 접속 중인지 확인
                    for m in channel.members:
                        if bot_id and str(m.id) == bot_id:
                            bot_connected = True
                            bot_channel_name = channel.name
                            break

                    if len(channel.members) > 0:
                        real_members = [m for m in channel.members if not m.bot]
                        if len(real_members) > 0:
                            result[str(guild.id)] = {
                                'channel_id': str(channel.id),
                                'channel_name': channel.name,
                                'member_count': len(real_members),
                                'bot_connected': bot_connected,
                                'bot_channel_name': bot_channel_name
                            }
                            break

                # 봇만 접속 중이고 유저가 없는 경우도 표시
                if bot_connected and str(guild.id) not in result:
                    result[str(guild.id)] = {
                        'channel_id': '',
                        'channel_name': bot_channel_name,
                        'member_count': 0,
                        'bot_connected': True,
                        'bot_channel_name': bot_channel_name
                    }
            return result
        except Exception as e:
            logger.error(f'음성 활동 서버 조회 실패: {e}')
            return {}

    def is_ready(self) -> bool:
        """Gateway 연결 준비 상태"""
        return self.ready and self.client.is_ready()

    def get_recent_message_events(self, channel_id: str = None, since_id: int = None) -> List[Dict]:
        """최근 메시지 이벤트 가져오기

        Args:
            channel_id: 특정 채널의 메시지만 필터링 (선택사항)
            since_id: 이 ID 이후의 이벤트만 반환 (선택사항)

        Returns:
            메시지 이벤트 리스트
        """
        events = self.message_events.copy()

        # 채널 필터링
        if channel_id:
            events = [e for e in events if e.get('channel_id') == str(channel_id)]

        # ID 기반 필터링 (since_id 이후 것만)
        if since_id is not None:
            events = [e for e in events if int(e['message']['id']) > since_id]

        return events

    async def start(self):
        """Gateway 서비스 시작"""
        try:
            logger.info(f'🚀 웹패널 Gateway 서비스 시작...')
            await self.client.start(self.token)
        except Exception as e:
            logger.error(f'❌ Gateway 시작 실패: {e}')
            raise

    async def close(self):
        """Gateway 연결 종료"""
        if not self.client.is_closed():
            await self.client.close()
            logger.info('🔌 웹패널 Gateway 연결 종료')


# 전역 서비스 인스턴스
_gateway_service: Optional[WebPanelGatewayService] = None

def get_gateway_service() -> Optional[WebPanelGatewayService]:
    """전역 Gateway 서비스 인스턴스 반환"""
    return _gateway_service

async def start_gateway_service(token: str):
    """Gateway 서비스 시작 (비동기)"""
    global _gateway_service

    if _gateway_service:
        await _gateway_service.close()

    _gateway_service = WebPanelGatewayService(token)
    await _gateway_service.start()

def start_gateway_service_thread(token: str):
    """Gateway 서비스를 별도 스레드에서 시작 (백그라운드, 대기 없음)"""

    def run_service():
        asyncio.set_event_loop(asyncio.new_event_loop())
        loop = asyncio.get_event_loop()
        try:
            loop.run_until_complete(start_gateway_service(token))
        except Exception as e:
            logger.error(f'Gateway 서비스 스레드 오류: {e}')
        finally:
            loop.close()

    thread = threading.Thread(target=run_service, daemon=True)
    thread.start()
    logger.info('웹패널 Gateway 서비스 백그라운드 시작됨 (연결 대기 없음)')
    return True  # 바로 반환, 백그라운드에서 연결
