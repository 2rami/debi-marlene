"""
Discord API 호출 함수들
"""
import ssl
import aiohttp


def _create_ssl_context():
    """로컬 개발용 SSL 컨텍스트 (macOS Python SSL 인증서 문제 우회)"""
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx


async def get_bot_guilds(headers):
    """Discord API에서 봇이 참여한 서버 목록 가져오기"""
    try:
        connector = aiohttp.TCPConnector(ssl=_create_ssl_context())
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.get('https://discord.com/api/v10/users/@me/guilds?with_counts=true',
                                 headers=headers) as response:
                if response.status == 200:
                    guilds = await response.json()
                    return [{
                        'id': guild['id'],
                        'name': guild['name'],
                        'icon': guild.get('icon'),
                        'approximate_member_count': guild.get('approximate_member_count', 0),
                        'approximate_presence_count': guild.get('approximate_presence_count', 0)
                    } for guild in guilds]
                return []
    except Exception as e:
        print(f"Discord API 오류 (봇 서버 목록): {e}")
        return []


async def get_discord_user_info(user_id, headers):
    """Discord API에서 사용자 정보 가져오기"""
    try:
        connector = aiohttp.TCPConnector(ssl=_create_ssl_context())
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.get(f'https://discord.com/api/v10/users/{user_id}',
                                 headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        'avatar': data.get('avatar'),
                        'username': data.get('username'),
                        'discriminator': data.get('discriminator')
                    }
                return None
    except Exception as e:
        print(f"Discord API 오류 (사용자 {user_id}): {e}")
        return None


async def get_discord_channels(guild_id, headers):
    """Discord API에서 서버 채널 목록 가져오기 (스레드 포함)"""
    try:
        connector = aiohttp.TCPConnector(ssl=_create_ssl_context())
        async with aiohttp.ClientSession(connector=connector) as session:
            # 일반 채널 가져오기
            async with session.get(f'https://discord.com/api/v10/guilds/{guild_id}/channels',
                                 headers=headers) as response:
                if response.status == 200:
                    channels_data = await response.json()
                else:
                    return []

            # 활성 스레드 가져오기 (포럼 포스트 포함)
            threads_data = []
            async with session.get(f'https://discord.com/api/v10/guilds/{guild_id}/threads/active',
                                 headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    threads_data = data.get('threads', [])

            # 채널 목록 구성
            channels = [{
                'id': ch['id'],
                'name': ch['name'],
                'type': ch['type'],
                'position': ch.get('position', 0),
                'parent_id': ch.get('parent_id')
            } for ch in channels_data]

            # 스레드 추가 (포럼 포스트 등)
            for thread in threads_data:
                channels.append({
                    'id': thread['id'],
                    'name': thread['name'],
                    'type': thread['type'],  # 10, 11, 12
                    'position': thread.get('position', 999),
                    'parent_id': thread.get('parent_id'),
                    'is_thread': True
                })

            return channels
    except Exception as e:
        print(f"Discord API 오류 (채널 목록 {guild_id}): {e}")
        return []


async def get_discord_dms(headers):
    """Discord API에서 DM 채널 목록 가져오기"""
    try:
        connector = aiohttp.TCPConnector(ssl=_create_ssl_context())
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.get('https://discord.com/api/v10/users/@me/channels',
                                 headers=headers) as response:
                if response.status == 200:
                    channels = await response.json()
                    # DM 채널만 필터링 (type=1은 개인 DM, type=3은 그룹 DM)
                    return [{
                        'id': ch['id'],
                        'name': ch.get('name') or (
                            ', '.join([u['username'] for u in ch.get('recipients', [])])
                            if ch['type'] == 1
                            else f"Group DM ({len(ch.get('recipients', []))} members)"
                        ),
                        'type': ch['type'],
                        'recipients': [
                            {
                                'id': u['id'],
                                'username': u['username'],
                                'discriminator': u.get('discriminator'),
                                'avatar': u.get('avatar')
                            }
                            for u in ch.get('recipients', [])
                        ]
                    } for ch in channels if ch['type'] in [1, 3]]  # 개인 DM과 그룹 DM만 포함
                return []
    except Exception as e:
        print(f"Discord API 오류 (DM 채널 목록): {e}")
        return []


async def send_discord_message(channel_id, content, headers, embed=None):
    """Discord API로 메시지 전송

    Args:
        channel_id: 메시지를 전송할 채널 ID
        content: 메시지 내용 (None 가능, embed와 함께 사용 시)
        headers: Discord API 헤더
        embed: Discord embed 객체 (선택, dict 형식)
               예: {'title': '제목', 'description': '내용', 'color': 16737131, 'timestamp': '...'}
    """
    try:
        connector = aiohttp.TCPConnector(ssl=_create_ssl_context())
        async with aiohttp.ClientSession(connector=connector) as session:
            data = {}
            if content:
                data['content'] = content
            if embed:
                data['embeds'] = [embed]  # Discord API는 embeds 배열 형식 요구

            async with session.post(f'https://discord.com/api/v10/channels/{channel_id}/messages',
                                  headers=headers,
                                  json=data) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error_text = await response.text()
                    print(f"메시지 전송 실패 ({response.status}): {error_text}")
                    return None
    except Exception as e:
        print(f"Discord API 오류 (메시지 전송 {channel_id}): {e}")
        return None
