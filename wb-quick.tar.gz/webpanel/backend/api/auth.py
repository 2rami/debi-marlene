"""
인증 API 핸들러
"""
from flask import jsonify, session


def check_auth():
    """로그인 상태 확인 API"""
    if 'user_id' in session:
        return jsonify({
            'authenticated': True,
            'user_id': session.get('user_id'),
            'username': session.get('username')
        })
    else:
        return jsonify({'authenticated': False})


def logout():
    """로그아웃 API"""
    session.clear()
    return jsonify({'success': True, 'message': '로그아웃되었습니다'})
