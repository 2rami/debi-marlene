"""
데비&마를렌 봇 웹 관리 패널 - 백엔드
"""
import os
import sys

# run 모듈 경로 추가
backend_dir = os.path.dirname(os.path.abspath(__file__))
webpanel_dir = os.path.dirname(backend_dir)

# Docker 환경 감지 (/app에서 실행)
if webpanel_dir == '/app':
    # Docker: run은 /app/run에 있음
    debi_marlene_dir = '/app'
    print(f"Docker 모드: run 경로 = {debi_marlene_dir}")
elif 'app.asar.unpacked' in backend_dir:
    # 일렉트론 프로덕션: run은 Resources/run에 있음
    resources_dir = os.path.dirname(webpanel_dir)
    debi_marlene_dir = resources_dir
    print(f"일렉트론 프로덕션 모드: run 경로 = {resources_dir}")
else:
    # 개발 모드: webpanel의 부모 폴더 = debi-marlene
    debi_marlene_dir = os.path.dirname(webpanel_dir)
    print(f"개발 모드: run 경로 = {debi_marlene_dir}")

# run 폴더가 있는 경로를 sys.path에 추가
if debi_marlene_dir not in sys.path:
    sys.path.insert(0, debi_marlene_dir)

print(f"Backend 모듈 로드 - run 경로 추가: {debi_marlene_dir}")
