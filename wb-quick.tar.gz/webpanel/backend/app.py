#!/usr/bin/env python3
"""
데비&마를렌 봇 웹 관리 패널 - 메인 앱
"""
import os
import sys

# 현재 디렉토리를 Python path에 추가 (Electron에서 실행할 때 필요)
# 이렇게 하면 'backend' 모듈과 'run' 모듈을 찾을 수 있어요!
current_dir = os.path.dirname(os.path.abspath(__file__))  # backend 폴더
parent_dir = os.path.dirname(current_dir)  # webpanel 폴더 또는 app.asar.unpacked
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# GCS 인증 파일 경로 설정
# 1. app.asar.unpacked (parent_dir) 확인
gcs_path_candidates = [
    os.path.join(parent_dir, 'gcs-credentials.json'),
    os.path.join(os.path.dirname(parent_dir), 'gcs-credentials.json'), # Resources
    os.path.abspath('gcs-credentials.json') # CWD
]

gcs_credentials_path = None
for path in gcs_path_candidates:
    if os.path.exists(path):
        gcs_credentials_path = path
        break

print(f"--- GCS 설정 디버깅 ---")
print(f"Current Dir: {current_dir}")
print(f"Parent Dir: {parent_dir}")
print(f"Candidates: {gcs_path_candidates}")

if gcs_credentials_path:
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = gcs_credentials_path
    print(f"✅ GCS 인증 파일 찾음: {gcs_credentials_path}")
else:
    print(f"❌ GCS 인증 파일을 찾을 수 없습니다!")
    # 파일 목록 출력해보기
    try:
        print(f"Parent Dir Contents: {os.listdir(parent_dir)}")
    except:
        pass

# Electron 프로덕션 환경: run 모듈 경로 추가
if os.environ.get('ELECTRON_APP') == 'true':
    # 1. app.asar.unpacked/run 경로 시도
    run_path_asar = os.path.join(parent_dir, 'run')
    if os.path.exists(run_path_asar) and run_path_asar not in sys.path:
        sys.path.insert(0, parent_dir)
        print(f"run 모듈 경로 추가 (asar.unpacked): {run_path_asar}")
    
    # 2. Resources/run 경로 시도
    resources_dir = os.path.dirname(parent_dir)
    run_path_resources = os.path.join(resources_dir, 'run')
    if os.path.exists(run_path_resources) and run_path_resources not in sys.path:
        sys.path.insert(0, resources_dir)
        print(f"run 모듈 경로 추가 (Resources): {run_path_resources}")
    
    # run 모듈 확인
    try:
        import run.core.config
        print(f"✅ run.core.config import 성공: {run.core.config.__file__}")
    except ImportError as e:
        print(f"❌ run 모듈 import 실패: {e}")
        print(f"sys.path: {sys.path}")

from flask import Flask, request, jsonify, session
from flask_cors import CORS
from functools import wraps

# API 보안 키
API_SECRET_KEY = os.environ.get('API_SECRET_KEY', 'debi-marlene-api-secret-x7k9m2p4')

# 백엔드 모듈 import
from backend.config import Config, DIST_FOLDER, DISCORD_BOT_TOKEN
from backend.routes.auth_routes import auth_bp
from backend.routes.main_routes import main_bp
from backend.routes.api_routes import api_bp
print(f"최종 GCS 인증 파일 경로: {os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')}")

# Gateway 서비스 import
try:
    from backend.gateway import get_gateway_service, start_gateway_service_thread
    GATEWAY_SERVICE_AVAILABLE = True
    print("웹패널 Gateway 모듈 로드 완료")
except ImportError as e:
    print(f"Gateway 모듈 로드 실패: {e}")
    GATEWAY_SERVICE_AVAILABLE = False


def create_app():
    """Flask 앱 생성 및 설정"""
    app = Flask(__name__,
                static_folder=DIST_FOLDER,
                static_url_path='')

    # 설정 적용
    app.config.from_object(Config)

    # CORS 설정 (로컬 + Vercel 프로덕션)
    CORS(app, supports_credentials=True, origins=[
        'http://localhost:5173',
        'http://127.0.0.1:5173',
        'https://panel.debimarlene.com',
    ])

    # 블루프린트 등록
    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp)

    # API 키 검증 미들웨어
    @app.before_request
    def check_api_key():
        if request.path.startswith('/api'):
            # 세션 인증된 사용자는 허용
            if 'user_id' in session:
                return None

            # 인증 관련 엔드포인트는 API 키 불필요
            auth_paths = ['/api/check-auth', '/api/logout', '/api/auth/']
            if any(request.path.startswith(p) for p in auth_paths):
                return None

            # API 키 검증
            api_key = request.headers.get('X-API-Key') or request.args.get('api_key')
            if api_key != API_SECRET_KEY:
                return jsonify({'error': 'Unauthorized', 'message': 'Invalid API key'}), 401
        return None

    print(f"Flask SECRET_KEY 설정됨: {app.config['SECRET_KEY'][:10]}...")

    return app


def main():
    """메인 함수"""
    import logging

    # Flask werkzeug 로거를 WARNING 레벨로 설정 (INFO 로그 숨김)
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.WARNING)

    print("🚀 데비&마를렌 웹패널 서버 시작")
    print("   - 실행 환경: 일렉트론 앱 / 로컬 개발")

    # Gateway 서비스 시작 (멤버 리스트 & 온라인 상태)
    if GATEWAY_SERVICE_AVAILABLE:
        print("   - Discord Gateway: 실시간 멤버 리스트 & 온라인 상태")
        print("   - Gateway 연결 시작 중...")
        gateway_started = start_gateway_service_thread(DISCORD_BOT_TOKEN)
        if gateway_started:
            print("   ✅ Gateway 연결 성공")
        else:
            print("   ⚠️  Gateway 연결 실패 - REST API 백업 사용")
    else:
        print("   - Discord Gateway: 비활성화 (REST API 사용)")

    print("   - 웹패널 모드: GCS 데이터 뷰어 + REST API")
    print("   - Discord 메시지 인터페이스: 활성화")

    # Flask 앱 생성
    app = create_app()

    # 서버 시작 (환경변수 PORT 또는 기본값 8080)
    # Vite 개발 서버와 Electron이 8080을 기본 프록시 대상으로 사용
    port = int(os.environ.get('PORT', 8080))
    print(f"   - 서버 포트: {port}")
    app.run(host='0.0.0.0', port=port, debug=False)


if __name__ == '__main__':
    main()
