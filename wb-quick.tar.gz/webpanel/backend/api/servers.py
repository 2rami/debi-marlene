"""
서버 API 핸들러
"""
import asyncio
from flask import jsonify
import requests as req
from backend.services.discord_api import get_bot_guilds
from backend.config import DISCORD_HEADERS


def get_servers():
    """API: 서버 목록 조회"""
    try:
        # Discord API에서 실시간 서버 목록 가져오기
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        discord_guilds = loop.run_until_complete(get_bot_guilds(DISCORD_HEADERS))
        loop.close()

        # 봇 설정 로드
        try:
            from run.core import config
        except ImportError:
            import config
        settings = config.load_settings()
        stored_guilds = settings.get('guilds', {})

        servers = []
        for discord_guild in discord_guilds:
            guild_id = discord_guild['id']
            guild_info = stored_guilds.get(guild_id, {})

            # Discord 아이콘 URL 생성
            icon_url = None
            if discord_guild.get('icon'):
                icon_url = f"https://cdn.discordapp.com/icons/{guild_id}/{discord_guild['icon']}.png?size=128"

            servers.append({
                'id': guild_id,
                'name': discord_guild['name'],
                'member_count': discord_guild.get('approximate_member_count', 0),
                'online_count': discord_guild.get('approximate_presence_count', 0),
                'status': 'Active' if guild_info.get('ANNOUNCEMENT_CHANNEL_ID') else '설정 필요',
                'invite_link': guild_info.get('초대링크', '#'),
                'join_date': guild_info.get('가입일', 'Discord API 기반'),
                'announcement_channel': guild_info.get('ANNOUNCEMENT_CHANNEL_NAME', '미설정'),
                'announcement_channel_id': guild_info.get('ANNOUNCEMENT_CHANNEL_ID'),
                'chat_channel': guild_info.get('CHAT_CHANNEL_NAME', '미설정'),
                'icon': discord_guild.get('icon'),
                'icon_url': icon_url,
                'chat_channel_id': guild_info.get('CHAT_CHANNEL_ID'),
                'data_source': 'Discord API + 설정 파일'
            })

        return jsonify({
            'servers': servers,
            'data_source': 'Discord API + 설정 파일',
            'total_servers': len(servers),
            'total_members': sum(s.get('member_count', 0) for s in servers),
            'total_online': sum(s.get('online_count', 0) for s in servers)
        })

    except Exception as e:
        print(f"API 서버 목록 로드 실패: {e}")
        # 실패 시 백업 데이터 사용
        try:
            from run.core import config
            settings = config.load_settings()
            guilds = settings.get('guilds', {})

            servers = []
            for guild_id, guild_info in guilds.items():
                if guild_info.get('상태') != '삭제됨':
                    servers.append({
                        'id': guild_id,
                        'name': guild_info.get('GUILD_NAME', 'Unknown'),
                        'member_count': guild_info.get('멤버수', '백업 데이터'),
                        'online_count': 0,
                        'status': guild_info.get('상태', 'Active'),
                        'invite_link': guild_info.get('초대링크', '#'),
                        'join_date': guild_info.get('가입일', 'Unknown'),
                        'announcement_channel': guild_info.get('ANNOUNCEMENT_CHANNEL_NAME', '미설정'),
                        'announcement_channel_id': guild_info.get('ANNOUNCEMENT_CHANNEL_ID'),
                        'chat_channel': guild_info.get('CHAT_CHANNEL_NAME', '미설정'),
                        'chat_channel_id': guild_info.get('CHAT_CHANNEL_ID'),
                        'data_source': '백업 데이터'
                    })

            return jsonify({
                'servers': servers,
                'data_source': '백업 데이터 (Discord API 오류)',
                'error': f"Discord API 오류: {str(e)}"
            })
        except:
            return jsonify({
                'servers': [],
                'error': str(e),
                'data_source': '완전 실패'
            })


def get_bot_info():
    """API: 봇 정보 가져오기 (프로필 사진, 이름, 태그)"""
    try:
        # Discord API에서 봇 정보 가져오기
        response = req.get('https://discord.com/api/v10/users/@me', headers=DISCORD_HEADERS)
        if response.status_code == 200:
            bot_data = response.json()
            avatar_url = None
            if bot_data.get('avatar'):
                avatar_url = f"https://cdn.discordapp.com/avatars/{bot_data['id']}/{bot_data['avatar']}.png"

            return jsonify({
                'success': True,
                'bot': {
                    'id': bot_data['id'],
                    'username': bot_data['username'],
                    'discriminator': bot_data['discriminator'],
                    'avatar': bot_data.get('avatar'),
                    'avatar_url': avatar_url
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Discord API 오류: {response.status_code}'
            })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })
