"""
사용자 API 핸들러
"""
import os
import asyncio
import aiohttp
from flask import jsonify, request
import requests as req
from backend.services.discord_api import get_discord_user_info
from backend.config import DISCORD_HEADERS
from backend.utils.helpers import get_discord_avatar_url


def get_bot_user():
    """API: Discord 봇 사용자 정보 조회"""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        # Discord API에서 봇 사용자 정보 가져오기
        async def get_bot_user_async():
            async with aiohttp.ClientSession() as session:
                async with session.get('https://discord.com/api/v10/users/@me',
                                     headers=DISCORD_HEADERS) as response:
                    if response.status == 200:
                        return await response.json()
                    return None

        bot_user = loop.run_until_complete(get_bot_user_async())
        loop.close()

        if bot_user:
            return jsonify({
                'success': True,
                'user': bot_user
            })
        else:
            return jsonify({
                'success': False,
                'error': '봇 사용자 정보를 가져올 수 없습니다.',
                'user': None
            })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'user': None
        })


def get_user_info(user_id):
    """API: Discord 사용자 기본 정보 조회"""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        user_info = loop.run_until_complete(get_discord_user_info(user_id, DISCORD_HEADERS))
        loop.close()

        if user_info:
            # 아바타 URL 생성
            avatar_url = None
            if user_info.get('avatar'):
                avatar_url = f"https://cdn.discordapp.com/avatars/{user_id}/{user_info['avatar']}.png?size=128"
            else:
                # 기본 Discord 아바타
                avatar_url = f"https://cdn.discordapp.com/embed/avatars/{int(user_id) % 5}.png"

            return jsonify({
                'success': True,
                'user': {
                    'id': user_id,
                    'username': user_info.get('username'),
                    'discriminator': user_info.get('discriminator'),
                    'avatar': user_info.get('avatar'),
                    'avatar_url': avatar_url,
                    'global_name': user_info.get('global_name'),
                    'public_flags': user_info.get('public_flags', 0)
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': '사용자 정보를 찾을 수 없습니다.'
            })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })


def get_user_profile(user_id):
    """API: Discord 사용자 프로필 상세 정보 조회 (배너, 소개글 포함)"""
    try:
        print(f"👤 사용자 프로필 조회: {user_id}")

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        # Discord API에서 사용자 정보 가져오기
        async def fetch_user_profile():
            async with aiohttp.ClientSession() as session:
                # 사용자 기본 정보 (배너, bio 포함)
                async with session.get(
                    f'https://discord.com/api/v10/users/{user_id}',
                    headers=DISCORD_HEADERS
                ) as response:
                    if response.status == 200:
                        return await response.json()
                    return None

        user_data = loop.run_until_complete(fetch_user_profile())

        if not user_data:
            loop.close()
            return jsonify({
                'success': False,
                'error': '사용자를 찾을 수 없습니다.'
            }), 404

        # GCS에서 사용자가 속한 서버 목록 가져오기
        from run.core import config
        from run.core.bot import bot

        settings = config.load_settings()
        user_settings = settings.get('users', {}).get(str(user_id), {})

        # 사용자가 속한 서버 찾기
        user_guilds = []
        for guild in bot.guilds:
            member = guild.get_member(int(user_id))
            if member:
                # 역할 정보
                roles = [
                    {
                        'id': str(role.id),
                        'name': role.name,
                        'color': role.color.value,
                        'position': role.position
                    }
                    for role in member.roles if role.name != "@everyone"
                ]

                user_guilds.append({
                    'id': str(guild.id),
                    'name': guild.name,
                    'icon': guild.icon.url if guild.icon else None,
                    'joined_at': member.joined_at.isoformat() if member.joined_at else None,
                    'nickname': member.nick,
                    'roles': roles
                })

        loop.close()

        # 아바타 URL
        avatar_url = None
        if user_data.get('avatar'):
            avatar_url = f"https://cdn.discordapp.com/avatars/{user_id}/{user_data['avatar']}.png?size=512"
        else:
            avatar_url = f"https://cdn.discordapp.com/embed/avatars/{int(user_id) % 5}.png"

        # 배너 URL
        banner_url = None
        if user_data.get('banner'):
            banner_url = f"https://cdn.discordapp.com/banners/{user_id}/{user_data['banner']}.png?size=600"

        # 응답 데이터
        profile = {
            'id': user_id,
            'username': user_data.get('username'),
            'discriminator': user_data.get('discriminator', '0'),
            'global_name': user_data.get('global_name'),
            'avatar': user_data.get('avatar'),
            'avatar_url': avatar_url,
            'banner': user_data.get('banner'),
            'banner_url': banner_url,
            'banner_color': user_data.get('banner_color'),
            'accent_color': user_data.get('accent_color'),
            'bio': user_data.get('bio'),
            'public_flags': user_data.get('public_flags', 0),
            'guilds': user_guilds,
            'interaction_count': user_settings.get('interaction_count', 0),
            'youtube_subscribed': user_settings.get('youtube_subscribed', False),
            'last_interaction': user_settings.get('last_interaction'),
            'last_dm': user_settings.get('last_dm')
        }

        print(f"✅ 프로필 조회 성공: {user_data.get('username')} ({len(user_guilds)}개 서버)")

        return jsonify({
            'success': True,
            'profile': profile
        })

    except Exception as e:
        print(f"❌ 사용자 프로필 조회 실패: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


def get_dm_channels():
    """API: Discord DM 채널 목록 조회 (GCS + Discord API 통합)"""
    try:
        print(f"📩 DM 채널 목록 가져오는 중 (GCS + Discord API)...")

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        # 1. GCS에서 저장된 DM 채널 가져오기
        from run.core import config
        settings = config.load_settings()
        users = settings.get('users', {})
        print(f"   GCS: {len(users)}명의 사용자 데이터 발견")

        # 2. Discord API에서 최신 DM 채널 가져오기
        async def get_bot_dm_channels():
            async with aiohttp.ClientSession() as session:
                async with session.get('https://discord.com/api/v10/users/@me/channels',
                                     headers=DISCORD_HEADERS) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        print(f"   Discord API 오류: {response.status}")
                        return []

        discord_dm_channels = loop.run_until_complete(get_bot_dm_channels())
        print(f"   Discord API: {len(discord_dm_channels)}개 최신 채널")

        # 3. 두 데이터 소스 합치기
        dm_channels_dict = {}  # user_id를 키로 사용

        # GCS 데이터 먼저 추가 (모든 상호작용한 사용자 - DM 채널 ID 유무 관계없이!)
        for user_id, user_info in users.items():
            # Discord API에서 실시간 사용자 정보 가져오기
            discord_user_info = loop.run_until_complete(get_discord_user_info(user_id, DISCORD_HEADERS))

            avatar_hash = None
            username = user_info.get('user_name', 'Unknown')
            global_name = None

            if discord_user_info:
                avatar_hash = discord_user_info.get('avatar')
                username = discord_user_info.get('username', username)
                global_name = discord_user_info.get('global_name')

            # 아바타 URL 생성
            avatar_url = get_discord_avatar_url(user_id, avatar_hash)

            # DM 채널 ID가 있으면 사용, 없으면 null (프론트에서 처리)
            dm_channel_id = user_info.get('dm_channel_id')

            dm_channels_dict[user_id] = {
                'id': dm_channel_id if dm_channel_id else f'temp_{user_id}',  # 임시 ID
                'type': 1,
                'recipient': {
                    'id': user_id,
                    'username': username,
                    'avatar': avatar_url,
                    'discriminator': '0',
                    'global_name': global_name
                },
                'last_message_id': None,
                'has_dm_channel': bool(dm_channel_id),  # DM 채널 존재 여부
                'source': 'GCS'
            }

        # Discord API 데이터로 업데이트 (최신 정보 우선)
        for channel in discord_dm_channels:
            if channel.get('type') == 1:  # DM 채널
                recipients = channel.get('recipients', [])
                if recipients:
                    recipient = recipients[0]
                    user_id = recipient.get('id')
                    username = recipient.get('username', 'Unknown')
                    avatar_hash = recipient.get('avatar')
                    avatar_url = get_discord_avatar_url(user_id, avatar_hash)

                    dm_channels_dict[user_id] = {
                        'id': channel.get('id'),
                        'type': 1,
                        'recipient': {
                            'id': user_id,
                            'username': username,
                            'avatar': avatar_url,
                            'discriminator': recipient.get('discriminator', '0'),
                            'global_name': recipient.get('global_name')
                        },
                        'last_message_id': channel.get('last_message_id'),
                        'source': 'Discord API'
                    }

        # 리스트로 변환
        dm_channels = list(dm_channels_dict.values())

        loop.close()

        print(f"✅ 총 {len(dm_channels)}개 DM 채널 (GCS + Discord API 통합)")
        return jsonify({
            'success': True,
            'channels': dm_channels,
            'count': len(dm_channels),
            'data_source': 'GCS + Discord API (통합)'
        })

    except Exception as e:
        print(f"❌ DM 채널 조회 실패: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e),
            'channels': []
        })


def create_dm_channel():
    """API: Discord DM 채널 생성 (Discord API 직접 호출)"""
    try:
        data = request.get_json()
        recipient_id = data.get('recipient_id')

        if not recipient_id:
            return jsonify({
                'success': False,
                'error': 'recipient_id가 필요합니다.'
            })

        print(f"💬 DM 채널 생성 시도 (Discord API): {recipient_id}")

        # Discord API로 DM 채널 생성
        discord_response = req.post(
            'https://discord.com/api/v10/users/@me/channels',
            headers=DISCORD_HEADERS,
            json={'recipient_id': recipient_id},
            timeout=10
        )

        if discord_response.status_code == 200:
            channel_data = discord_response.json()
            print(f"✅ DM 채널 생성 성공: {channel_data.get('id')}")

            # GCS에는 저장하지 않음 - 실제 메시지를 받을 때 bot.py에서 저장

            return jsonify({
                'success': True,
                'channel': channel_data
            })
        else:
            error_text = discord_response.text
            print(f"❌ DM 채널 생성 실패 ({discord_response.status_code}): {error_text}")

            error_message = "DM 채널 생성에 실패했습니다."
            if discord_response.status_code == 403:
                error_message = "이 사용자는 DM을 차단했습니다."
            elif discord_response.status_code == 404:
                error_message = "사용자를 찾을 수 없습니다."

            return jsonify({
                'success': False,
                'error': error_message
            }), discord_response.status_code

    except Exception as e:
        print(f"❌ DM 채널 생성 오류: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
