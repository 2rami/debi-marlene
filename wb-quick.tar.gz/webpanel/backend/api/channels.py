"""
채널 API 핸들러
"""
import asyncio
import aiohttp
from flask import jsonify
from backend.services.discord_api import get_discord_channels, get_discord_dms
from backend.config import DISCORD_HEADERS
from backend.gateway import get_gateway_service


def get_channels(guild_id):
    """API: Discord 서버 채널 목록 조회"""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        channels = loop.run_until_complete(get_discord_channels(guild_id, DISCORD_HEADERS))
        loop.close()

        return jsonify({
            'success': True,
            'channels': channels
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'channels': []
        })


def get_dms():
    """API: DM 채널 목록 조회"""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        dms = loop.run_until_complete(get_discord_dms(DISCORD_HEADERS))
        loop.close()

        return jsonify({
            'success': True,
            'dms': dms,
            'count': len(dms)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'dms': [],
            'count': 0
        })


def get_voice_channel_members(channel_id):
    """API: 음성 채널에 접속한 멤버 목록 조회"""
    try:
        gateway = get_gateway_service()
        if not gateway or not gateway.is_ready():
            return jsonify({
                'success': False,
                'error': 'Gateway 서비스가 준비되지 않았습니다',
                'members': []
            })

        members = gateway.get_voice_channel_members_sync(channel_id)

        return jsonify({
            'success': True,
            'members': members,
            'count': len(members)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'members': []
        })


def get_forum_threads(channel_id, guild_id):
    """API: 포럼 채널의 스레드(포스트) 목록 조회"""
    from flask import request

    # guild_id가 없으면 쿼리 파라미터에서 가져오기
    if not guild_id:
        guild_id = request.args.get('guild_id')

    async def fetch_threads():
        threads = []
        thread_ids = set()

        async with aiohttp.ClientSession() as session:
            # 1. 길드의 활성 스레드에서 해당 포럼 채널의 것만 필터링
            if guild_id:
                async with session.get(
                    f'https://discord.com/api/v10/guilds/{guild_id}/threads/active',
                    headers=DISCORD_HEADERS
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        print(f"[포럼] 활성 스레드 조회 성공: guild={guild_id}, 총 {len(data.get('threads', []))}개")
                        for thread in data.get('threads', []):
                            # parent_id가 해당 포럼 채널인 것만
                            if thread.get('parent_id') == channel_id:
                                thread_ids.add(thread['id'])
                                threads.append({
                                    'id': thread['id'],
                                    'name': thread['name'],
                                    'type': thread['type'],
                                    'message_count': thread.get('message_count', 0),
                                    'member_count': thread.get('member_count', 0),
                                    'archived': False,
                                    'created_at': thread.get('thread_metadata', {}).get('create_timestamp'),
                                    'owner_id': thread.get('owner_id')
                                })
                        print(f"[포럼] 채널 {channel_id}의 활성 스레드: {len(threads)}개")
                    else:
                        print(f"[포럼] 활성 스레드 조회 실패: guild={guild_id}, status={response.status}")

            # 2. 아카이브된 공개 스레드
            async with session.get(
                f'https://discord.com/api/v10/channels/{channel_id}/threads/archived/public',
                headers=DISCORD_HEADERS
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    print(f"[포럼] 아카이브 스레드 조회 성공: channel={channel_id}, {len(data.get('threads', []))}개")
                    for thread in data.get('threads', []):
                        if thread['id'] not in thread_ids:
                            thread_ids.add(thread['id'])
                            threads.append({
                                'id': thread['id'],
                                'name': thread['name'],
                                'type': thread['type'],
                                'message_count': thread.get('message_count', 0),
                                'member_count': thread.get('member_count', 0),
                                'archived': thread.get('thread_metadata', {}).get('archived', False),
                                'created_at': thread.get('thread_metadata', {}).get('create_timestamp'),
                                'owner_id': thread.get('owner_id')
                            })
                else:
                    print(f"[포럼] 아카이브 스레드 조회 실패: channel={channel_id}, status={response.status}")

        print(f"[포럼] 최종 스레드 수: {len(threads)}개")
        return threads

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        threads = loop.run_until_complete(fetch_threads())
        loop.close()

        return jsonify({
            'success': True,
            'threads': threads,
            'count': len(threads)
        })
    except Exception as e:
        print(f"포럼 스레드 조회 오류: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'threads': [],
            'count': 0
        })
