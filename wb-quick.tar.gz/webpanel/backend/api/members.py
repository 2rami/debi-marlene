"""
멤버 API 핸들러
"""
from flask import jsonify, request
import requests as req
from backend.config import DISCORD_HEADERS
from backend.utils.helpers import get_discord_avatar_url


def get_members(guild_id):
    """API: Discord 서버 멤버 목록 조회 (Gateway 우선, REST API 백업)"""
    try:
        # 채널 ID가 쿼리 파라미터로 전달되면 해당 채널의 멤버만 필터링
        channel_id = request.args.get('channel_id')

        # Gateway 서비스 사용 가능하면 Gateway 사용 (실시간 온라인 상태 포함)
        try:
            from backend.gateway import get_gateway_service
            GATEWAY_SERVICE_AVAILABLE = True
        except ImportError:
            GATEWAY_SERVICE_AVAILABLE = False

        if GATEWAY_SERVICE_AVAILABLE:
            gateway_service = get_gateway_service()
            if gateway_service and gateway_service.is_ready():
                print(f"Gateway로 멤버 목록 로드 (실시간 상태 포함): {guild_id}")
                members = gateway_service.get_guild_members_sync(guild_id, channel_id)

                if members:
                    print(f"Gateway에서 {len(members)}명의 멤버 가져옴 (실시간 온라인 상태 포함)")
                    return jsonify({
                        'success': True,
                        'members': members,
                        'data_source': 'Gateway (실시간 온라인 상태)',
                        'count': len(members)
                    })
                else:
                    print(f"Gateway에서 멤버를 가져올 수 없음, REST API 사용")

        # Gateway 사용 불가능 또는 실패 시 REST API 사용
        print(f"Discord REST API로 멤버 목록 로드: {guild_id}")
        try:
            # Discord API에서 멤버 목록 가져오기 (최대 1000명)
            response = req.get(
                f'https://discord.com/api/v10/guilds/{guild_id}/members',
                headers=DISCORD_HEADERS,
                params={'limit': 1000}
            )

            if response.status_code == 200:
                members_data = response.json()
                members = []

                for member in members_data:
                    user = member.get('user', {})
                    avatar_hash = user.get('avatar')

                    # 아바타 URL 생성 (애니메이션 GIF 지원)
                    avatar_url = get_discord_avatar_url(user.get('id'), avatar_hash)

                    # 서버 내 닉네임 (nick) 또는 username 사용
                    display_name = member.get('nick') or user.get('username', 'Unknown')

                    # 봇 여부 확인
                    is_bot = user.get('bot', False)

                    members.append({
                        'id': user.get('id'),
                        'username': user.get('username'),
                        'discriminator': user.get('discriminator', '0'),
                        'nick': member.get('nick'),
                        'display_name': display_name,
                        'avatar': avatar_url,
                        'status': 'offline',  # REST API로는 실시간 상태 알 수 없음
                        'bot': is_bot,
                        'roles': member.get('roles', []),
                        'role_color': None,
                        'top_role': None,
                        'joined_at': member.get('joined_at')
                    })

                print(f"Discord API에서 {len(members)}명의 멤버 가져옴")
                return jsonify({
                    'success': True,
                    'members': members,
                    'data_source': 'Discord REST API (백업)',
                    'count': len(members)
                })
            else:
                print(f"Discord API 오류: {response.status_code}")
                return jsonify({
                    'success': False,
                    'error': f'Discord API 오류: {response.status_code}',
                    'members': []
                })

        except Exception as e:
            print(f"Discord API 요청 실패: {e}")
            return jsonify({
                'success': False,
                'error': f'Discord API 요청 실패: {str(e)}',
                'members': []
            })

    except Exception as e:
        print(f"멤버 목록 API 오류: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'members': []
        })


def get_roles(guild_id):
    """API: Discord 서버 역할 목록 조회 (GCS 데이터 사용)"""
    try:
        # 웹패널은 역할 목록을 제공하지 않음
        print(f"역할 목록 기능은 봇에서만 사용 가능합니다")
        return jsonify({
            'success': True,
            'roles': [],
            'data_source': '봇에서만 사용 가능',
            'count': 0,
            'message': '역할 목록은 봇의 Gateway 연결을 통해 수집됩니다'
        })
    except Exception as e:
        print(f"역할 목록 API 오류: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'roles': []
        })
