"""
인증 라우트
"""
import os
from flask import Blueprint, request, redirect, url_for, session, send_from_directory
import requests as req
from backend.config import DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, OWNER_ID, DIST_FOLDER

auth_bp = Blueprint('auth', __name__)

# 환경변수 기반 URL (프로덕션: https://panel.debimarlene.com, 로컬: http://localhost:8080)
BASE_URL = os.getenv('WEBPANEL_BASE_URL', 'http://localhost:8080')
FRONTEND_URL = os.getenv('WEBPANEL_FRONTEND_URL', 'http://localhost:5173')


@auth_bp.route('/login')
def login():
    """Discord OAuth 로그인 - React 앱 표시"""
    if os.getenv('ELECTRON_APP'):
        return send_from_directory(DIST_FOLDER, 'index.html')
    else:
        error = request.args.get('error')
        if error:
            return redirect(f'{FRONTEND_URL}/?error={error}')
        return redirect(f'{FRONTEND_URL}/')


@auth_bp.route('/auth/callback')
def auth_callback():
    """Discord OAuth 콜백 처리"""
    code = request.args.get('code')
    if not code:
        return redirect(url_for('auth.login'))

    redirect_uri = f'{BASE_URL}/auth/callback'

    token_url = 'https://discord.com/api/oauth2/token'
    data = {
        'client_id': DISCORD_CLIENT_ID,
        'client_secret': DISCORD_CLIENT_SECRET,
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': redirect_uri
    }

    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    token_response = req.post(token_url, data=data, headers=headers)
    print(f"토큰 교환 응답 상태 코드: {token_response.status_code}")
    print(f"토큰 교환 응답 내용: {token_response.text}")
    if token_response.status_code != 200:
        return redirect(url_for('auth.login', error=f'Discord 인증 실패: {token_response.text}'))

    token_json = token_response.json()
    access_token = token_json.get('access_token')

    # 사용자 정보 가져오기
    user_url = 'https://discord.com/api/users/@me'
    headers = {
        'Authorization': f'Bearer {access_token}'
    }

    user_response = req.get(user_url, headers=headers)
    if user_response.status_code != 200:
        return redirect(url_for('auth.login', error='사용자 정보 조회 실패'))

    user_data = user_response.json()
    user_id = user_data.get('id')
    username = user_data.get('username')

    # OWNER_ID 확인
    print(f"Discord 사용자 ID: {user_id} (타입: {type(user_id)})")
    print(f"설정된 OWNER_ID: {OWNER_ID} (타입: {type(OWNER_ID)})")
    print(f"ID 비교 결과: {user_id == OWNER_ID}")

    if str(user_id) != str(OWNER_ID):
        print(f"접근 거부: {user_id} != {OWNER_ID}")
        return redirect(url_for('auth.login', error=f'접근 권한이 없습니다. 사용자 ID: {user_id}'))

    # 세션 저장
    session['user_id'] = user_id
    session['username'] = username
    session.permanent = True
    session.modified = True

    print(f"세션 저장 완료: user_id={session.get('user_id')}, username={session.get('username')}")
    print(f"세션 permanent={session.permanent}, modified={session.modified}")

    if os.getenv('ELECTRON_APP'):
        return redirect('http://localhost:8080/')
    else:
        return redirect(f'{FRONTEND_URL}/')


@auth_bp.route('/logout')
def logout():
    """로그아웃"""
    session.clear()
    return redirect(url_for('auth.login'))


@auth_bp.route('/auth/discord')
def auth_discord():
    """Discord OAuth 인증 시작 - 실제 Discord로 리다이렉트"""
    redirect_uri = f'{BASE_URL}/auth/callback'

    discord_auth_url = (
        f"https://discord.com/api/oauth2/authorize?"
        f"client_id={DISCORD_CLIENT_ID}&"
        f"redirect_uri={redirect_uri}&"
        f"response_type=code&"
        f"scope=identify"
    )
    return redirect(discord_auth_url)
