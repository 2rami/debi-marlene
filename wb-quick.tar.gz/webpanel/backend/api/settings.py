"""
설정 API 핸들러
"""
import json
from datetime import datetime
from flask import jsonify, request
import pytz

# 한국 시간대 설정
KST = pytz.timezone('Asia/Seoul')


def get_raw_settings():
    """API: 원본 설정 파일 조회"""
    try:
        from run.core import config
        settings = config.load_settings()
        print("Raw settings API 호출됨")
        # settings를 pretty JSON 문자열로 변환
        pretty_settings_json = json.dumps(settings, indent=2, ensure_ascii=False)
        response_data = {
            'success': True,
            'settings_json': pretty_settings_json,
            'settings': settings,
            'last_updated': datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')
        }
        from flask import current_app
        return current_app.response_class(
            response=json.dumps(response_data, indent=2, ensure_ascii=False),
            status=200,
            mimetype='application/json'
        )
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'settings': {}
        })


def load_settings():
    """API: GCS에서 설정 파일 로드 (GCS SDK 사용)"""
    try:
        # GCS SDK 사용 (로컬/Electron/Cloud Run 모두 작동)
        from run.core import config
        config.settings_cache = None  # 캐시 무효화
        config.cache_timestamp = 0
        settings = config.load_settings()
        
        # GCS 연결 상태 확인
        gcs_connected = config.get_gcs_client() is not None

        return jsonify({
            'success': True,
            'settings': settings,
            'data_source': 'GCS SDK',
            'gcs_connected': gcs_connected,
            'last_updated': datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')
        })
    except Exception as e:
        print(f"설정 로드 실패: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'settings': {}
        })


def save_settings():
    """API: 설정 파일 저장"""
    try:
        data = request.get_json()
        if not data or 'settings' not in data:
            return jsonify({
                'success': False,
                'error': '유효하지 않은 요청 데이터입니다.'
            })

        settings = data['settings']

        # JSON 유효성 재검증
        if not isinstance(settings, dict):
            return jsonify({
                'success': False,
                'error': '설정 데이터는 JSON 객체여야 합니다.'
            })

        # 설정 저장
        from run.core import config
        success = config.save_settings(settings)

        if success:
            print(f"설정 파일 저장 완료: {len(str(settings))} bytes")
            return jsonify({
                'success': True,
                'message': '설정이 성공적으로 저장되었습니다.',
                'timestamp': datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')
            })
        else:
            return jsonify({
                'success': False,
                'error': '저장 중 오류가 발생했습니다.'
            })

    except json.JSONDecodeError as e:
        return jsonify({
            'success': False,
            'error': f'JSON 파싱 오류: {str(e)}'
        })
    except Exception as e:
        print(f"설정 저장 오류: {e}")
        return jsonify({
            'success': False,
            'error': f'저장 중 오류가 발생했습니다: {str(e)}'
        })
