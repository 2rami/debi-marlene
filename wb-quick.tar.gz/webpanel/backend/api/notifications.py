"""
알림 API 핸들러

명령어 사용 내역을 조회하는 API
"""
from flask import jsonify, request


def get_command_logs():
    """API: 명령어 사용 로그 조회"""
    print(f"[알림 API] 명령어 로그 조회 요청 받음", flush=True)
    try:
        # config 모듈 import
        try:
            from run.core import config
        except ImportError:
            import config

        # 쿼리 파라미터에서 필터 가져오기
        filters = {}

        if request.args.get('guild_id'):
            filters['guild_id'] = request.args.get('guild_id')

        if request.args.get('user_id'):
            filters['user_id'] = request.args.get('user_id')

        if request.args.get('command_name'):
            filters['command_name'] = request.args.get('command_name')

        if request.args.get('start_date'):
            filters['start_date'] = request.args.get('start_date')

        if request.args.get('end_date'):
            filters['end_date'] = request.args.get('end_date')

        # limit (기본값: 100)
        limit = request.args.get('limit', 100, type=int)
        filters['limit'] = limit

        print(f"[알림 API] 필터: {filters}", flush=True)

        # GCS에서 로그 로드
        logs = config.load_command_logs(filters)
        print(f"[알림 API] 로그 개수: {len(logs)}", flush=True)

        # 통계 계산
        command_stats = {}
        for log in logs:
            cmd_name = log.get('command_name', 'Unknown')
            if cmd_name not in command_stats:
                command_stats[cmd_name] = 0
            command_stats[cmd_name] += 1

        print(f"[알림 API] 응답 성공 - 로그 {len(logs)}개, 통계: {command_stats}", flush=True)
        return jsonify({
            'success': True,
            'logs': logs,
            'total_count': len(logs),
            'command_stats': command_stats,
            'filters': filters
        })

    except Exception as e:
        print(f"[오류] 명령어 로그 조회 실패: {e}", flush=True)
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e),
            'logs': []
        }), 500
