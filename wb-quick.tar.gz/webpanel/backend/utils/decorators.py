"""
데코레이터 함수들
"""
from functools import wraps
from flask import session, redirect, url_for, request


def login_required(f):
    """로그인 필요 데코레이터"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id_in_session = session.get('user_id')
        print(f"로그인 확인: session에 user_id={user_id_in_session} 있음? {'user_id' in session}")
        if 'user_id' not in session:
            print(f"로그인 필요 - {request.url}로 리다이렉트")
            return redirect(url_for('auth.login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function
