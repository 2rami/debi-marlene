"""
퀴즈 글로벌 곡 목록 관리 API 핸들러

웹패널(봇 소유자 전용)에서 글로벌 곡 목록을 CRUD합니다.
"""
import json
import logging
from flask import jsonify, request

logger = logging.getLogger(__name__)

GCS_BUCKET = 'debi-marlene-settings'
GCS_QUIZ_KEY = 'quiz_data.json'
_gcs_client = None


def _get_gcs_client():
    global _gcs_client
    if _gcs_client is None:
        try:
            from google.cloud import storage
            _gcs_client = storage.Client(project='ironic-objectivist-465713-a6')
        except Exception as e:
            logger.error(f'GCS 클라이언트 생성 실패: {e}')
            _gcs_client = False
    return _gcs_client if _gcs_client is not False else None


def _load_quiz_data():
    client = _get_gcs_client()
    if client:
        try:
            bucket = client.bucket(GCS_BUCKET)
            blob = bucket.blob(GCS_QUIZ_KEY)
            if not blob.exists():
                return {"songs": [], "guilds": {}}
            return json.loads(blob.download_as_text())
        except Exception as e:
            logger.error(f'퀴즈 데이터 로드 실패: {e}')
    return {"songs": [], "guilds": {}}


def _save_quiz_data(data):
    client = _get_gcs_client()
    if client:
        try:
            json_data = json.dumps(data, indent=2, ensure_ascii=False)
            bucket = client.bucket(GCS_BUCKET)
            blob = bucket.blob(GCS_QUIZ_KEY)
            blob.upload_from_string(json_data, content_type='application/json')
            return True
        except Exception as e:
            logger.error(f'퀴즈 데이터 저장 실패: {e}')
    return False


def get_songs():
    """글로벌 곡 목록 조회"""
    data = _load_quiz_data()
    songs = data.get('songs', [])
    return jsonify({'songs': songs, 'count': len(songs)})


def add_song():
    """글로벌 곡 추가"""
    body = request.json
    if not body:
        return jsonify({'error': 'Request body required'}), 400

    title = body.get('title', '').strip()
    artist = body.get('artist', '').strip()
    query = body.get('query', '').strip()
    aliases = body.get('aliases', [])

    if not title or not artist or not query:
        return jsonify({'error': 'title, artist, query are required'}), 400

    data = _load_quiz_data()
    songs = data.setdefault('songs', [])

    song = {'title': title, 'artist': artist, 'query': query}
    if aliases:
        song['aliases'] = [a.strip() for a in aliases if a.strip()]
    title_aliases = body.get('title_aliases', [])
    if title_aliases:
        song['title_aliases'] = [a.strip() for a in title_aliases if a.strip()]

    songs.append(song)
    _save_quiz_data(data)
    return jsonify({'success': True, 'song': song, 'index': len(songs) - 1})


def update_song(index):
    """글로벌 곡 수정"""
    body = request.json
    if not body:
        return jsonify({'error': 'Request body required'}), 400

    data = _load_quiz_data()
    songs = data.get('songs', [])

    if index < 0 or index >= len(songs):
        return jsonify({'error': 'Invalid index'}), 404

    title = body.get('title', '').strip()
    artist = body.get('artist', '').strip()
    query = body.get('query', '').strip()
    aliases = body.get('aliases', [])

    if not title or not artist or not query:
        return jsonify({'error': 'title, artist, query are required'}), 400

    songs[index] = {'title': title, 'artist': artist, 'query': query}
    if aliases:
        songs[index]['aliases'] = [a.strip() for a in aliases if a.strip()]
    title_aliases = body.get('title_aliases', [])
    if title_aliases:
        songs[index]['title_aliases'] = [a.strip() for a in title_aliases if a.strip()]

    _save_quiz_data(data)
    return jsonify({'success': True, 'song': songs[index]})


def delete_song(index):
    """글로벌 곡 삭제"""
    data = _load_quiz_data()
    songs = data.get('songs', [])

    if index < 0 or index >= len(songs):
        return jsonify({'error': 'Invalid index'}), 404

    removed = songs.pop(index)
    _save_quiz_data(data)
    return jsonify({'success': True, 'removed': removed})
