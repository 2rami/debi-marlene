"""
메인 라우트
"""
from datetime import datetime
from flask import Blueprint, send_from_directory, jsonify
import pytz
from backend.config import DIST_FOLDER, APP_VERSION
from backend.utils.decorators import login_required

# 한국 시간대 설정
KST = pytz.timezone('Asia/Seoul')

main_bp = Blueprint('main', __name__)


@main_bp.route('/')
@login_required
def discord_interface():
    """React 기반 디스코드 인터페이스"""
    return send_from_directory(DIST_FOLDER, 'index.html')


@main_bp.route('/version')
def version():
    """버전 정보 - 공개 엔드포인트"""
    return jsonify({
        'version': APP_VERSION,
        'timestamp': datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S KST'),
        'features': ['monaco-editor', 'json-pretty-print', 'channel-names']
    })


@main_bp.route('/<path:path>')
@login_required
def catch_all(path):
    """React Router를 위한 catch-all route"""
    # API나 auth 요청이 아닌 경우 index.html 제공
    if not path.startswith('api/') and not path.startswith('auth/'):
        return send_from_directory(DIST_FOLDER, 'index.html')
    # 그 외에는 404
    return jsonify({'error': 'Not found'}), 404
