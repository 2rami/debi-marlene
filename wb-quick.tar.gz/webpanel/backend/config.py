"""
Flask 앱 설정
"""
import os
from datetime import timedelta
from dotenv import load_dotenv

# .env 파일 로드 (현재 폴더 webpanel/.env 우선)
# override=False로 설정하여 app.py에서 이미 설정한 환경변수(GCS 절대 경로 등)를 유지
load_dotenv(override=False)
dotenv_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env')
if os.path.exists(dotenv_path):
    load_dotenv(dotenv_path, override=False)
    print(f"webpanel/.env 로드 완료: {dotenv_path}")


# 앱 버전
APP_VERSION = '2.0.0'

# dist 폴더 경로 계산 (절대 경로 사용)
SCRIPT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 일렉트론 패키징된 앱인지 확인 (app.asar.unpacked 폴더 안에 있는 경우)
if 'app.asar.unpacked' in SCRIPT_DIR:
    # 프로덕션: dist는 Resources 폴더에 있음 (app.asar.unpacked의 상위)
    DIST_FOLDER = os.path.join(os.path.dirname(SCRIPT_DIR), 'dist')
    print(f"일렉트론 프로덕션: dist 폴더를 Resources에서 찾음")
else:
    # 개발 모드: dist는 webpanel 폴더에 있음
    DIST_FOLDER = os.path.join(SCRIPT_DIR, 'dist')
    print(f"개발 모드: dist 폴더를 로컬에서 찾음")

print(f"Static folder (dist): {DIST_FOLDER}")


# Discord Bot 토큰 (경로는 backend/__init__.py에서 설정됨)
try:
    from run.core import config as bot_config
    DISCORD_BOT_TOKEN = bot_config.DISCORD_TOKEN or os.getenv('DISCORD_BOT_TOKEN')
except ImportError:
    print("Warning: run.core.config import 실패, 환경변수 사용")
    DISCORD_BOT_TOKEN = os.getenv('DISCORD_BOT_TOKEN') or os.getenv('DISCORD_TOKEN')

# Discord API 헤더
DISCORD_HEADERS = {
    'Authorization': f'Bot {DISCORD_BOT_TOKEN}',
    'Content-Type': 'application/json'
}

# Owner Discord ID (전역 변수로 정의)
OWNER_ID = os.getenv('OWNER_ID', '809085215237996584').strip()

# Discord OAuth 설정
DISCORD_CLIENT_ID = os.getenv('DISCORD_CLIENT_ID')
DISCORD_CLIENT_SECRET = os.getenv('DISCORD_CLIENT_SECRET')

print(f"Discord OAuth 설정:")
print(f"   CLIENT_ID: {DISCORD_CLIENT_ID}")


class Config:
    """Flask 설정 클래스"""
    # 세션 설정
    SECRET_KEY = os.getenv('SESSION_SECRET_KEY', 'debi-marlene-web-panel-fixed-secret-key-2025')
    PERMANENT_SESSION_LIFETIME = timedelta(hours=24)
    SESSION_COOKIE_PATH = '/'

    # 환경별 세션 쿠키 설정
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'

    if os.getenv('FLASK_ENV') == 'production':
        PREFERRED_URL_SCHEME = 'https'
        SESSION_COOKIE_SECURE = True
    else:
        PREFERRED_URL_SCHEME = 'http'
        SESSION_COOKIE_SECURE = False
