"""
공지 API 핸들러
"""
import asyncio
from datetime import datetime, timezone
from flask import jsonify, request
from backend.services.discord_api import send_discord_message
from backend.config import DISCORD_HEADERS


def get_announcement_servers():
    """API: 공지 채널이 설정된 서버 목록 조회"""
    try:
        from run.core import config
        settings = config.load_settings()
        guilds = settings.get('guilds', {})

        # ANNOUNCEMENT_CHANNEL_ID가 설정된 서버만 필터링
        announcement_servers = []
        for guild_id, guild_settings in guilds.items():
            announcement_channel_id = guild_settings.get('ANNOUNCEMENT_CHANNEL_ID')
            if announcement_channel_id:
                announcement_servers.append({
                    'guild_id': guild_id,
                    'guild_name': guild_settings.get('GUILD_NAME', '알 수 없음'),
                    'announcement_channel_id': announcement_channel_id,
                    'announcement_channel_name': guild_settings.get('ANNOUNCEMENT_CHANNEL_NAME', '알 수 없음')
                })

        return jsonify({
            'success': True,
            'servers': announcement_servers,
            'count': len(announcement_servers)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'servers': []
        })


def get_youtube_subscribers():
    """API: 유튜브 알림을 구독한 사용자 목록 조회"""
    try:
        from run.core import config
        from backend.services.discord_api import get_discord_user_info

        settings = config.load_settings()
        users = settings.get('users', {})

        # youtube_subscribed가 True인 사용자만 필터링
        subscriber_ids = []
        for user_id, user_settings in users.items():
            if user_settings.get('youtube_subscribed'):
                subscriber_ids.append({
                    'user_id': user_id,
                    'dm_channel_id': user_settings.get('dm_channel_id')
                })

        # Discord API로 실제 사용자 정보 가져오기
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        async def fetch_user_info(user_data):
            user_info = await get_discord_user_info(user_data['user_id'], DISCORD_HEADERS)
            if user_info:
                return {
                    'user_id': user_data['user_id'],
                    'username': user_info.get('username', '알 수 없음'),
                    'dm_channel_id': user_data['dm_channel_id']
                }
            return {
                'user_id': user_data['user_id'],
                'username': '알 수 없음',
                'dm_channel_id': user_data['dm_channel_id']
            }

        async def fetch_all():
            tasks = [fetch_user_info(user_data) for user_data in subscriber_ids]
            return await asyncio.gather(*tasks)

        subscribers = loop.run_until_complete(fetch_all())
        loop.close()

        return jsonify({
            'success': True,
            'subscribers': subscribers,
            'count': len(subscribers)
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'subscribers': []
        })


def send_announcement():
    """API: 공지 메시지 전송"""
    try:
        data = request.get_json()
        targets = data.get('targets', [])  # 타겟 채널 ID 목록
        title = data.get('title', '').strip()
        content = data.get('content', '').strip()
        announcement_type = data.get('type', 'server')  # 'server' or 'dm'

        # 입력 검증
        if not title:
            return jsonify({
                'success': False,
                'error': '제목을 입력해주세요.'
            })

        if not content:
            return jsonify({
                'success': False,
                'error': '내용을 입력해주세요.'
            })

        if not targets:
            return jsonify({
                'success': False,
                'error': '전송할 대상을 선택해주세요.'
            })

        # Discord Embed 생성 (기존 /공지 명령어와 동일한 형식)
        embed = {
            'title': title,
            'description': content,
            'color': 16737131,  # 0xFF6B6B (부드러운 빨강색)
            'timestamp': datetime.now(timezone.utc).isoformat()
        }

        # 각 타겟에 메시지 전송
        results = {
            'success_count': 0,
            'fail_count': 0,
            'failed_targets': []
        }

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        for target_id in targets:
            try:
                result = loop.run_until_complete(
                    send_discord_message(target_id, None, DISCORD_HEADERS, embed=embed)
                )
                if result:
                    results['success_count'] += 1
                else:
                    results['fail_count'] += 1
                    results['failed_targets'].append({
                        'channel_id': target_id,
                        'reason': '메시지 전송 실패'
                    })
            except Exception as e:
                results['fail_count'] += 1
                results['failed_targets'].append({
                    'channel_id': target_id,
                    'reason': str(e)
                })

        loop.close()

        # 전송 결과 로그
        print(f"[공지] {announcement_type} 공지 전송 완료 - 성공: {results['success_count']}, 실패: {results['fail_count']}")

        return jsonify({
            'success': True,
            'results': results
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })
